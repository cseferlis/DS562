"""
Azure Functions entry point.

*** DO NOT MODIFY THIS FILE ***

This file is the entry point that Azure Functions calls.
All your implementation goes in weather_ingestion.py
"""

import azure.functions as func
from . import weather_ingestion

def main(mytimer: func.TimerRequest) -> None:
    """
    Timer trigger entry point.
    
    This function is called by Azure Functions on schedule.
    It delegates to the main() function in weather_ingestion.py
    
    Args:
        mytimer: Azure Functions timer context
    """
    if mytimer.past_due:
        import logging
        logging.info('The timer is past due!')
    
    # Call the main function in weather_ingestion.py
    weather_ingestion.main(mytimer)
