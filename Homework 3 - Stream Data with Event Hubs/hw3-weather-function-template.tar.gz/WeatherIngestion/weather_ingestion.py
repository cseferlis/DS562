"""
WeatherIngestion - Hourly data collection for Boston weather and air pollution

YOU IMPLEMENT:
- fetch_weather() - Call OpenWeather weather API
- fetch_pollution() - Call OpenWeather pollution API  
- combine_data() - Merge both datasets into required schema
- get_est_timestamp() - Convert UTC to EST
- Main orchestration logic

DO NOT MODIFY:
- send_to_eventhub() - Already implemented
- Anything in __init__.py
"""

import logging
import requests
import json
import os
from datetime import datetime
import pytz

# Boston coordinates
LATITUDE = 42.3601
LONGITUDE = -71.0589

# OpenWeather API endpoints
WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather"
POLLUTION_URL = "http://api.openweathermap.org/data/2.5/air_pollution"


def fetch_weather(lat, lon, api_key):
    """
    Fetch current weather data from OpenWeather API.
    
    Args:
        lat (float): Latitude
        lon (float): Longitude
        api_key (str): OpenWeather API key
    
    Returns:
        dict: Weather data JSON response, or None if request fails
    
    TODO: Implement this function
    
    Hints:
    - Use requests.get() to call WEATHER_URL
    - Pass parameters: lat, lon, appid (api_key), units='metric'
    - Handle exceptions (network errors, API errors)
    - Return response.json() if successful, None if failed
    - Log errors using logging.error()
    
    Example:
        weather_data = fetch_weather(42.3601, -71.0589, "your_api_key")
        if weather_data:
            print(weather_data['main']['temp'])  # Temperature in Celsius
    """
    try:
        # TODO: Implement API call
        # params = {...}
        # response = requests.get(WEATHER_URL, params=params, timeout=10)
        # response.raise_for_status()  # Raises exception for 4xx/5xx status codes
        # return response.json()
        pass
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching weather data: {e}")
        return None


def fetch_pollution(lat, lon, api_key):
    """
    Fetch current air pollution data from OpenWeather API.
    
    Args:
        lat (float): Latitude
        lon (float): Longitude
        api_key (str): OpenWeather API key
    
    Returns:
        dict: Pollution data JSON response, or None if request fails
    
    TODO: Implement this function (similar structure to fetch_weather)
    
    Hints:
    - Use requests.get() to call POLLUTION_URL
    - Pass parameters: lat, lon, appid (api_key)
    - Handle exceptions the same way as fetch_weather
    - Return response.json() if successful, None if failed
    """
    try:
        # TODO: Implement API call
        pass
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching pollution data: {e}")
        return None


def get_est_timestamp():
    """
    Get current timestamp in EST timezone as ISO 8601 string.
    
    Returns:
        str: Timestamp in format "2026-02-14T07:00:00-05:00"
    
    TODO: Implement this function
    
    Hints:
    - Get current UTC time: datetime.now(datetime.timezone.utc)
    - Create EST timezone: pytz.timezone('America/New_York')
    - Convert UTC to EST: utc_time.astimezone(est_timezone)
    - Format as ISO string: .isoformat()
    
    Example:
        timestamp = get_est_timestamp()
        print(timestamp)  # "2026-02-14T07:00:00-05:00"
    """
    # TODO: Implement timestamp conversion
    pass


def combine_data(weather, pollution, timestamp):
    """
    Combine weather and pollution data into the required message schema.
    
    Args:
        weather (dict): Weather API response
        pollution (dict): Pollution API response
        timestamp (str): EST timestamp string
    
    Returns:
        dict: Combined message matching the required schema
    
    TODO: Implement this function
    
    Required schema:
    {
      "city": "Boston",
      "latitude": 42.3601,
      "longitude": -71.0589,
      "timestamp": "<timestamp parameter>",
      "weather": <weather parameter>,
      "pollution": <pollution parameter>
    }
    
    Hints:
    - Create a dictionary with the required fields
    - Use LATITUDE and LONGITUDE constants
    - weather and pollution should be the complete API responses (don't modify them)
    """
    # TODO: Create and return combined data dictionary
    pass


def send_to_eventhub(data):
    """
    Send data to Event Hubs.
    
    *** ALREADY IMPLEMENTED - DO NOT MODIFY ***
    
    This function handles all Event Hubs communication.
    Just call it with your combined data dictionary.
    
    Args:
        data (dict): Message to send (will be JSON-serialized)
    
    Raises:
        Exception: If Event Hub connection or send fails
    """
    from azure.eventhub import EventHubProducerClient, EventData
    
    connection_str = os.getenv("EVENT_HUB_CONNECTION_STRING")
    eventhub_name = "weather-events"
    
    if not connection_str:
        raise ValueError("EVENT_HUB_CONNECTION_STRING environment variable not set")
    
    try:
        producer = EventHubProducerClient.from_connection_string(
            conn_str=connection_str, 
            eventhub_name=eventhub_name
        )
        
        event_data_batch = producer.create_batch()
        event_data_batch.add(EventData(json.dumps(data)))
        producer.send_batch(event_data_batch)
        producer.close()
        
        logging.info("✓ Data sent to Event Hubs successfully")
    except Exception as e:
        logging.error(f"✗ Error sending data to Event Hub: {e}")
        raise


def main(mytimer):
    """
    Main function that runs on hourly schedule.
    
    TODO: Implement the orchestration logic
    
    Required steps:
    1. Get API key from environment variable (os.getenv("OPENWEATHER_API_KEY"))
    2. Call fetch_weather() for Boston coordinates
    3. Call fetch_pollution() for Boston coordinates
    4. Get current timestamp in EST
    5. If BOTH API calls succeeded:
         - Call combine_data() with all three pieces
         - Call send_to_eventhub() with combined data
         - Log success
    6. If either API call failed:
         - Log which one failed
         - Do NOT send partial data
         - Function completes normally (don't raise exception)
    
    Error handling strategy:
    - If an API fails: log error, skip this hour, function succeeds
    - If Event Hub send fails: let exception propagate (function fails, Azure knows)
    
    Why this strategy?
    - Missing one hour of data is acceptable (we'll get data next hour)
    - But if Event Hubs is down, we want Azure to mark function as failed
    """
    logging.info("=== WeatherIngestion function started ===")
    
    # Get API key from environment variable
    api_key = os.getenv("OPENWEATHER_API_KEY")
    if not api_key:
        logging.error("✗ OPENWEATHER_API_KEY environment variable not set")
        return
    
    # TODO: Implement orchestration logic here
    # 
    # Steps:
    # 1. Call fetch_weather(LATITUDE, LONGITUDE, api_key)
    # 2. Call fetch_pollution(LATITUDE, LONGITUDE, api_key)
    # 3. Check if both returned data (not None)
    # 4. If both succeeded:
    #      - Get timestamp: get_est_timestamp()
    #      - Combine data: combine_data(weather, pollution, timestamp)
    #      - Send to Event Hubs: send_to_eventhub(combined)
    #      - Log success
    # 5. If either failed:
    #      - Log which API failed
    #      - Return without sending
    
    logging.info("=== WeatherIngestion function completed ===")
