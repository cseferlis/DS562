# HW3 Weather Ingestion Function - Template

This is the starter template for HW3. Follow the instructions in the main homework README.

## Project Structure

```
hw3-weather-function/
├── WeatherIngestion/
│   ├── __init__.py              # Entry point (DO NOT MODIFY)
│   ├── function.json            # Timer trigger config (DO NOT MODIFY)
│   └── weather_ingestion.py    # YOUR CODE GOES HERE
├── .gitignore                   # Prevents committing secrets
├── host.json                    # Function app settings
├── requirements.txt             # Python dependencies
├── local.settings.json.template # Template for local config
└── README.md                    # This file
```

## Setup Instructions

### 1. Configure Local Settings

```bash
# Rename the template
cp local.settings.json.template local.settings.json

# Edit local.settings.json and fill in:
# - EVENT_HUB_CONNECTION_STRING (from Part 1 of homework)
# - OPENWEATHER_API_KEY (from HW1)
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Implement Your Code

Open `WeatherIngestion/weather_ingestion.py` and implement:
- `fetch_weather()` - Call OpenWeather API
- `fetch_pollution()` - Call pollution API
- `get_est_timestamp()` - Convert UTC to EST
- `combine_data()` - Merge into required schema
- `main()` - Orchestration logic

**Do NOT modify:**
- `__init__.py` - Entry point
- `send_to_eventhub()` - Already implemented

### 4. Test Locally

```bash
# In VS Code: Press F5 to start debugging
# Or in terminal:
func start
```

Manually trigger the function:
- VS Code: Right-click function → "Execute Function Now..."
- HTTP: `curl -X POST http://localhost:7071/admin/functions/WeatherIngestion`

### 5. Deploy to Azure

See main homework instructions for deployment steps.

## What You Need to Implement

### fetch_weather(lat, lon, api_key)

Call OpenWeather API and return JSON response or None on error.

**Hints:**
- URL: `http://api.openweathermap.org/data/2.5/weather`
- Parameters: `lat`, `lon`, `appid`, `units='metric'`
- Use `requests.get()`
- Handle exceptions

### fetch_pollution(lat, lon, api_key)

Call air pollution API (similar structure to fetch_weather).

**Hints:**
- URL: `http://api.openweathermap.org/data/2.5/air_pollution`
- Parameters: `lat`, `lon`, `appid`

### get_est_timestamp()

Convert current UTC time to EST and return ISO 8601 string.

**Hints:**
- Get UTC: `datetime.now(datetime.timezone.utc)`
- EST timezone: `pytz.timezone('America/New_York')`
- Convert: `utc_time.astimezone(est_timezone)`
- Format: `.isoformat()`

### combine_data(weather, pollution, timestamp)

Create dictionary with required schema.

**Required structure:**
```json
{
  "city": "Boston",
  "latitude": 42.3601,
  "longitude": -71.0589,
  "timestamp": "<timestamp>",
  "weather": <weather_data>,
  "pollution": <pollution_data>
}
```

### main(mytimer)

Orchestrate the data collection:

1. Get API key from environment
2. Call both API functions
3. Check both succeeded
4. Get timestamp
5. Combine data
6. Send to Event Hubs
7. Handle errors appropriately

## Error Handling Strategy

- **API fails:** Log error, don't send message, function succeeds
- **Event Hub fails:** Let exception propagate, function fails

**Why?**
- Skipping one hour is OK (we get data next hour)
- But Event Hub down should mark function as failed

## Timer Schedule

The function runs **every hour at minute :00** using NCRONTAB expression:

```
0 0 * * * *
```

This is configured in `function.json` and should not be changed.

## Testing Checklist

Before deploying to Azure, verify locally:

- [ ] Both API calls succeed
- [ ] Data combines into correct schema
- [ ] Timestamp is in EST timezone
- [ ] Message sends to Event Hubs
- [ ] No errors in logs
- [ ] Environment variables load correctly

## Common Issues

**"ModuleNotFoundError"**
→ Run `pip install -r requirements.txt`

**"OPENWEATHER_API_KEY not set"**
→ Check `local.settings.json` has correct key name

**"401 Unauthorized" from API**
→ Verify API key is active at openweathermap.org

**"ConnectError" to Event Hubs**
→ Verify connection string format in local.settings.json

## Getting Help

- Check the main HW3 README for detailed instructions
- Review the debugging guide (Level 1-4 approach)
- Test APIs independently before debugging your code
- Use VS Code debugger to step through and inspect variables

Good luck!
